%Fitiamos el calor_especifico con un polinomio de alg�n grado, lo
%imprimimos superpuesto al plot del calor espec�fico y buscamos cuanto vale
%la temperatura para el m�ximo
grado_del_polinomio = 20;
polinomio_de_ajuste = polyfit(temperatura', calor_especifico_media_64/4096, grado_del_polinomio);
x = linspace(0.1, 4.5, 1400);
y = polyval(polinomio_de_ajuste, x);
figure
plot(temperatura', calor_especifico_media_64/4096, '.');
hold on
plot(x,y)
hold off
%Buscamos el m�ximo y lo imprimimos. Nos quedamos con el que nos sirve que
%es la "Tc"
extremos = roots(polyder(polinomio_de_ajuste));
y1 = polyval(polinomio_de_ajuste, extremos);
horzcat(extremos, y1)
