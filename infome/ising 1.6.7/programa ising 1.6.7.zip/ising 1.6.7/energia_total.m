%funci�n que calcula la energia total de una configuraci�n sumando la
%energia de cada uno de sus componentes
function U = energia_total(Sij, beta, L)
    U = 0;
    for j=1:L
        for k=1:L
            U = U + energia_1_elemento(Sij, beta, j, k, L);
        end
    end
end