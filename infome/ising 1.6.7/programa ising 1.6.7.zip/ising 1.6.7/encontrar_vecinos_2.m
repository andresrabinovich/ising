function vecino = encontrar_vecinos(fila, columna, L)
    vecino = zeros(4, 2);
    vecino(1,1) = fila;
    vecino(1,2) = columna + 1;

    vecino(2,1) = fila + 1;
    vecino(2,2) = columna;

    if((fila + 1) > L)
        vecino(2, 1) = 1;
    end
    if((columna + 1) > L)
        vecino(1, 2) = 1;
    end
end