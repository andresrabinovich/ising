%funci�n que calcula la magnetizaci�n total de una configuraci�n sumando la
%magnetizaci�n de cada uno de sus componentes
function M = magnetizacion_total(Sij, L)
    M = 0;
    for j=1:L
        for k=1:L
            M = M + Sij(j, k);
        end
    end
end