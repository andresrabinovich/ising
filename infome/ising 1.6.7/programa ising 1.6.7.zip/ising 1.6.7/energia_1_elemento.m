%funcion para calcular la energia de un elemento. La calcula viendo la
%interacci�n entre si mismo y derecha y abajo
function U = energia_1_elemento(Sij, beta, fila, columna, L)

    j = 1; %El j de ising
    uB = 0; %El valor del campo magnetico aplicado por u

    M = Sij(fila, columna);
    U = 0;
    vecinos = encontrar_vecinos(fila, columna, L);
    for i=3:4
        U = U -j*M*Sij(vecinos(i, 1), vecinos(i, 2));
    end
end
