%borramos las figuras que ya estaban abiertas
delete(findall(0,'Type','figure'))

%energ�a media
figure
plot(temperatura, energia_media_10/100, 'r.')
hold on
plot(temperatura, energia_media_20/400, 'b.')
plot(temperatura, energia_media_50/2500, 'g.')
plot(temperatura, energia_media_64/4096, 'm.')
hold off
title('Energ�a media por part�cula')
xlabel('Temperatura')
ylabel('Energ�a')
legend('L = 10','L = 20','L = 50','L = 64', 'Location','northwest')
grid on

%Capacidad calor�fica
figure
plot(temperatura, calor_especifico_media_10/100, 'r.')
hold on
plot(temperatura, calor_especifico_media_20/400, 'b.')
plot(temperatura, calor_especifico_media_50/2500, 'g.')
plot(temperatura, calor_especifico_media_64/4096, 'm.')
hold off
title('Capacidad calor�fica')
xlabel('Temperatura')
ylabel('Cv')
legend('L = 10','L = 20','L = 50','L = 64', 'Location','northwest')
grid on

%Magnetizaci�n media
figure
plot(temperatura, abs(magnetizacion_media_10)/100, 'r.')
hold on
plot(temperatura, abs(magnetizacion_media_20)/400, 'b.')
plot(temperatura, abs(magnetizacion_media_50)/2500, 'g.')
plot(temperatura, abs(magnetizacion_media_64)/4096, 'm.')
hold off
title('Magnetizaci�n media por part�cula')
xlabel('Temperatura')
ylabel('Magnetizaci�n')
legend('L = 10','L = 20','L = 50','L = 64', 'Location','northwest')
grid on

%Susceptibilidad media
figure
plot(temperatura, susceptibilidad_media_10/100, 'r.')
hold on
plot(temperatura, susceptibilidad_media_20/400, 'b.')
plot(temperatura, susceptibilidad_media_50/2500, 'g.')
plot(temperatura, susceptibilidad_media_64/4096, 'm.')
hold off
title('Susceptibilidad magn�tica')
xlabel('Temperatura')
ylabel('Xm')
legend('L = 10','L = 20','L = 50','L = 64', 'Location','northwest')
grid on

%Termalizaciones
figure
flips = linspace(1, 200000, 48);
plot(flips, energias(:,1), 'r.')
hold on
plot(flips, energias(:,2), 'b.')
plot(flips, energias(:,3), 'g.')
hold off
title('Termalizaci�n (L = 64)')
xlabel('flips')
set(gca,'XTickLabel',num2str(get(gca,'XTick').'))
ylabel('Energia')
legend('T = 0.1', 'T = 2.3', 'T = 4.5', 'Location','northeast')
grid on

%Ajuste de cv
figure
x_recta=[2.2665,2.2665];
y_recta=[-1,2.5];
plot(x_recta, y_recta, 'r');
hold on
plot(temperatura', calor_especifico_media_64/4096, '.');
plot(x,y)
hold off
title('Cv y ajuste por polinomio de grado 20 (L = 64)')
xlabel('Temperatura')
ylabel('Cv')
legend('M�ximo = 2.26', 'Puntos simulados', 'Polinomio de ajuste', 'Location','northwest')
grid on