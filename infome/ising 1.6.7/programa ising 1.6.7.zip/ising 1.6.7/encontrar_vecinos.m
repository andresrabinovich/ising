%funci�n para encontrar los cuatro vecinos de un spin con condiciones de 
%contorno peri�dicas. Vecino 1 es arriba,
%vecino 2 es izquierda, vecino 3 es derecha y vecino 4 es abajo
function vecino = encontrar_vecinos(fila, columna, L)
    vecino = zeros(4, 2);
    
    vecino(1,1) = fila-1;
    vecino(1,2) = columna;

    vecino(2,1) = fila;
    vecino(2,2) = columna-1;

    vecino(3,1) = fila;
    vecino(3,2) = columna+1;

    vecino(4,1) = fila + 1;
    vecino(4,2) = columna;
   
    if((fila - 1) < 1)
        vecino(1, 1) = L;
    end
    if((columna - 1) < 1)
        vecino(2, 2) = L;
    end
    if((columna + 1) > L)
        vecino(3, 2) = 1;
    end
    if((fila + 1) > L)
        vecino(4, 1) = 1;
    end
end