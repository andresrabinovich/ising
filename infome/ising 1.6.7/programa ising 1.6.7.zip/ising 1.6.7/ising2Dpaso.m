%funcion que hace ising 2D. Recibe una matriz de -1's y 1's y beta, y
%devuelve la nueva matriz con las variaciones de cada cosa
function [Sij, U_configuracion, M_configuracion] = ising2Dpaso(Sij,beta,L)
    
    %calculo la energia de la configuraci�n
    pasos = 500;
    U = 0;
    M = sum(sum(Sij));
    for i = 1:L
        for j = 1:L
           U = U + energia_1_elemento(Sij, beta, [i, j], L);
        end
    end 
    U = U/2;
    U_medio = zeros(pasos, 1);
    M_medio = zeros(pasos, 1);
    %termalizo
    for i=1:1000
        for j=1:L
            for k=1:L
                Sij(j, k) = -Sij(j, k);
                U = energia_1_elemento(Sij, beta, j, k, L);
                if dU < 0 || exp(-beta*dU) > rand() %Acepto
                    U = U + dU;
                else
                    Sij(posicion_a_cambiar(1), posicion_a_cambiar(2)) = -Sij(posicion_a_cambiar(1), posicion_a_cambiar(2));    
                end
            end
        end
        U_medio(i) = U/i;
    end

    %hago issing!!
    for i=1:pasos
        for j=1:L
            for k=1:L
                posicion_a_cambiar = [j, k];
                Sij(posicion_a_cambiar(1), posicion_a_cambiar(2)) = -Sij(posicion_a_cambiar(1), posicion_a_cambiar(2));
                dU = energia_1_elemento(Sij, beta, posicion_a_cambiar, L);
                if dU < 0 || exp(-beta*dU) > rand() %Acepto
                    U = U + dU;
                    M = M + Sij(posicion_a_cambiar(1), posicion_a_cambiar(2));
                else
                    Sij(posicion_a_cambiar(1), posicion_a_cambiar(2)) = -Sij(posicion_a_cambiar(1), posicion_a_cambiar(2));    
                end
            end
        end
        M_medio(i) = M/i;
        U_medio(i) = U/i;
    end

    U_configuracion = mean(U_medio);
    M_configuracion = mean(M_medio);
    %for i=1:4
    %    [Uij(i), Mij(i)] = energia_1_elemento(Sij, beta, [vecinos(i,1), vecinos(i,2)], L);
    %    U_anterior = U_anterior + Uij_anterior(vecinos(i,1), vecinos(i,2)); %calculo la energia anterior de los vecinos
    %    M_anterior = M_anterior + Mij_anterior(vecinos(i,1), vecinos(i,2));
    %end
    %U_anterior = U_anterior + Uij_anterior(posicion_a_cambiar(1), posicion_a_cambiar(2)); %calculo la energia anterior de los vecinos
    %M_anterior = M_anterior + Mij_anterior(posicion_a_cambiar(1), posicion_a_cambiar(2));
    %[Uij(5), Mij(5)] = energia_1_elemento(Sij, beta, [posicion_a_cambiar(1) posicion_a_cambiar(2)], L);    
    %Sij(posicion_a_cambiar(1), posicion_a_cambiar(2)) = -Sij(posicion_a_cambiar(1), posicion_a_cambiar(2));
    
    %for i = 1:L
    %    for j = 1:L
    %       U = U + energia_1_elemento(Sij, beta, [i, j], L);
    %    end
    %end   
    %U_anterior = 0;
    %M_anterior = 0;
    
    %calculamos la energ�a y magnetizaci�n nuevas de los 4 vecinos y del elemento
    
    %for i=1:4
    %    [Uij(i), Mij(i)] = energia_1_elemento(Sij, beta, [vecinos(i,1), vecinos(i,2)], L);
    %    U_anterior = U_anterior + Uij_anterior(vecinos(i,1), vecinos(i,2)); %calculo la energia anterior de los vecinos
    %    M_anterior = M_anterior + Mij_anterior(vecinos(i,1), vecinos(i,2));
    %end
    %U_anterior = U_anterior + Uij_anterior(posicion_a_cambiar(1), posicion_a_cambiar(2)); %calculo la energia anterior de los vecinos
    %M_anterior = M_anterior + Mij_anterior(posicion_a_cambiar(1), posicion_a_cambiar(2));
    %[Uij(5), Mij(5)] = energia_1_elemento(Sij, beta, [posicion_a_cambiar(1) posicion_a_cambiar(2)], L);
    %U = sum(Uij);    %energia nueva
    %M = sum(Mij);
    
    %DE = U - U_anterior;
    %DM = M - M_anterior;
    
    %si se cumplen las condiciones para que la configuraci�n nueva sea
    %mejor que la vieja, cambiamos la nueva por la vieja. Si no, no
    %cambiamos nada y las variaciones son 0
    %if U < U_anterior || exp(-beta*DE) > rand()
        %for i=1:4
        %    Uij_anterior(vecinos(i,1), vecinos(i,2)) = Uij(i);
        %    Mij_anterior(vecinos(i,1), vecinos(i,2)) = Mij(i);
        %end
        %Uij_anterior(posicion_a_cambiar) = Uij(5);
        %Mij_anterior(posicion_a_cambiar) = Mij(5);
    %else
    %    Sij(posicion_a_cambiar(1), posicion_a_cambiar(2)) = -Sij(posicion_a_cambiar(1), posicion_a_cambiar(2));
    %    U = U_anterior;
    %end
end
