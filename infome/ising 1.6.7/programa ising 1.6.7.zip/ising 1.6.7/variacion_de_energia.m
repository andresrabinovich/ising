%Funci�n para calcular la variaci�n de energia en el sistema producto de un
%flip en un spin
function dU = variacion_de_energia(Sij, fila, columna, beta, L)
    energia_vieja = 0;
    energia_nueva = 0;
    vecinos = encontrar_vecinos(fila, columna, L);
    %calculamos la energ�a vieja del entorno invertido (arriba y derecha)
    for i=1:2
        energia_vieja = energia_vieja + energia_1_elemento(Sij, beta, vecinos(i, 1), vecinos(i, 2), L);
    end
    energia_vieja = energia_vieja + energia_1_elemento(Sij, beta, fila, columna, L);    
    
    %damos vuelta el spin
    Sij(fila, columna) = -Sij(fila, columna);

    %calculamos la energ�a nueva del entorno invertido (arriba y derecha)
    for i=1:2
        energia_nueva = energia_nueva + energia_1_elemento(Sij, beta, vecinos(i, 1), vecinos(i, 2), L);
    end
    energia_nueva = energia_nueva + energia_1_elemento(Sij, beta, fila, columna, L);    
    %devolvemos la variaci�n en la energia
    dU = energia_nueva - energia_vieja; 
    
end