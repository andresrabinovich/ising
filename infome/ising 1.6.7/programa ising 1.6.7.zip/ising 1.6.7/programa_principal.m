%Script para realizar ising monte carlo metr�polis con una red de L*L
%LIMPIAMOS EL AREA DE TRABAJO
clear
delete(findall(0,'Type','figure'))
bdclose('all')

%CONFIGURACIONES
L = 64; %Lado de la red
%Pasos de termalizacion (elegimos termalizar con 120000 flips despu�s de
%hacer varias pruebas)
termalizacion = 120000/L^2; 
%Pasos de ising. Cuantos m�s mejor, pero como el tiempo es finito, elegimos
%hacer 200 pasadas por cada temperatura
pasos_de_ising = 200; 
%HASTA ACA LAS CONFIGURACIONES

%Generamos el vector de temperaturas dando m�s puntos a las temperaturas de
%inter�s (desde 1.1 hasta 3.5 damos 120 puntos)
temperatura = horzcat(linspace(0.1,1,10), linspace(1.1,3.5,120), linspace(3.6,4.5,10));
pasos_totales = 10 + 10 + 120;

%Inicializamos variables;
energia_media = zeros(pasos_totales, 1);
magnetizacion_media = zeros(pasos_totales, 1);
susceptibilidad_media = zeros(pasos_totales, 1);
calor_especifico_media = zeros(pasos_totales, 1);
%Sirve para relacionar los vectores termodin�micos con la temperatura
paso_actual = 0; 

%Generamos una matriz de L*L al azar de -1's y 1's
Sij=2*(rand(L, L)>0.5) -1; 

%Termalizamos en T = 0.1 porque es lo m�s r�pido
beta = 1/0.1;
for i=1:termalizacion
    for j=1:L %j es filas
        for k=1:L %k es columnas
            dU = variacion_de_energia(Sij, j, k, beta, L);
            if dU < 0 || exp(-beta*dU) > rand() %Acepto
                Sij(j, k) = -Sij(j, k);
            end
        end
    end
end

%Comenzamos ising. Mostramos el paso actual, la temperatura actual y el
%tiempo que tard� en hacerlo
for T = temperatura
    tic
    paso_actual = paso_actual + 1
    T
    beta = 1/T;
    energias = zeros(pasos_de_ising, 1);
    magnetizaciones = zeros(pasos_de_ising, 1);    
    for i=1:pasos_de_ising
        for j=1:L %j es filas
            for k=1:L %k es columnas
                dU = variacion_de_energia(Sij, j, k, beta, L);
                if dU < 0 || exp(-beta*dU) > rand() %Acepto
                    Sij(j, k) = -Sij(j, k);
                end
            end
        end
        energias(i) = energia_total(Sij, beta, L);
        magnetizaciones(i) = magnetizacion_total(Sij, L);
    end
    energia_media(paso_actual) = mean(energias);
    calor_especifico_media(paso_actual) = (std(energias)/T)^2; 
    magnetizacion_media(paso_actual) = mean(magnetizaciones);
    susceptibilidad_media(paso_actual) = (std(magnetizaciones)^2)/T;
    toc
end
%Mostramos las figuras de cada vector termodin�mico. Lo que importa, de
%todas formas, es la salida en el workspace.
figure;
plot(temperatura, energia_media/L^2, '.');
grid on
title('Energ�a media por part�cula')
xlabel('Temperatura')
ylabel('Energ�a')
figure;
plot(temperatura, calor_especifico_media/L^2, '.');
grid on
title('Calor espec�fico')
xlabel('Temperatura')
ylabel('Cv')
figure;
plot(temperatura, magnetizacion_media/L^2, '.');
grid on
title('Magnetizaci�n media por part�cula')
xlabel('Temperatura')
ylabel('Magnetizaci�n')
figure;
plot(temperatura, susceptibilidad_media/L^2, '.');
grid on
title('Susceptibilidad magn�tica')
xlabel('Temperatura')
ylabel('Xm')