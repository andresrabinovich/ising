%Script para investigar distintas termalizaciones a diferentes temperaturas
%y diferentes redes.

%LIMPIAMOS EL AREA DE TRABAJO
clear
delete(findall(0,'Type','figure'))
bdclose('all')

%CONFIGURACIONES
temperaturas = [1/0.1, 1/2.3, 1/4.5]; 
L = 64; %Lado de la red
termalizacion = 48;
%HASTA ACA LAS CONFIGURACIONES

energias = zeros(termalizacion, 3);
paso = 0;
for beta = temperaturas
    paso = paso + 1
     %Generar una matriz de L*L al azar de -1's y 1's
    Sij=2*(rand(L, L)>0.5) -1;
    for i=1:termalizacion
        i
        for j=1:L %j es filas
            for k=1:L %k es columnas
                dU = variacion_de_energia(Sij, j, k, beta, L);
                if dU < 0 || exp(-beta*dU) > rand() %Acepto
                    Sij(j, k) = -Sij(j, k);
                end
            end
        end
        energias(i, paso) = energia_total(Sij, beta, L);
    end
end